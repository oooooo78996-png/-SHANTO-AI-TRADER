package com.shanto.aitrader

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val captureRequest = 101
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
        }
        val title = TextView(this).apply {
            text = "SHANTO AI TRADER PRO"
            textSize = 24f
        }
        status = TextView(this).apply {
            text = "প্রথমে Overlay permission দিন, তারপর Screen Capture চালু করুন।"
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        val overlay = Button(this).apply {
            text = "১. Enable Floating Button"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    status.text = "Floating permission enabled."
                }
            }
        }
        val start = Button(this).apply {
            text = "২. Start Screen Capture"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "আগে Overlay permission দিন", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
            }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(overlay)
        layout.addView(start)
        setContentView(layout)
    }

    @Deprecated("Deprecated Android callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("projectionData", data)
            }
            startForegroundService(service)
            status.text = "Screen capture permission granted. Floating analyzer is starting."
        } else if (requestCode == captureRequest) {
            status.text = "Screen capture permission was not granted."
        }
    }
}
