package com.shanto.aitrader

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class CaptureService : Service(), TextToSpeech.OnInitListener {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var windowManager: WindowManager? = null
    private var bubble: LinearLayout? = null
    private var tts: TextToSpeech? = null
    private var ready = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("projectionData", Intent::class.java)
                   else intent?.getParcelableExtra("projectionData")
        if (resultCode == Activity.RESULT_OK && data != null && projection == null) {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            startProjection()
            showBubble()
        }
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channelId = "shanto_capture"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Screen analysis", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId).setContentTitle("SHANTO AI TRADER")
                .setContentText("Screen capture is active only with your permission.")
                .setSmallIcon(android.R.drawable.ic_menu_view).build()
        else Notification.Builder(this).setContentTitle("SHANTO AI TRADER")
            .setContentText("Screen capture active").setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(7, notification)
    }

    private fun startProjection() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "ShantoScreenCapture", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null
        )
    }

    private fun showBubble() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(Color.rgb(18, 35, 48))
        }
        val result = TextView(this).apply {
            text = "SHANTO AI\nREADY"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
        }
        val scan = Button(this).apply {
            text = "ANALYZE"
            setOnClickListener {
                val image = reader?.acquireLatestImage()
                if (image != null) {
                    image.close()
                    result.text = "SCREEN CAPTURED\nChart image received.\nPattern analysis is not validated yet."
                    val spoken = "স্ক্রিন ক্যাপচার হয়েছে। চার্টের তথ্য পাওয়া গেছে। নির্ভরযোগ্য ট্রেড সিগন্যাল যাচাই করা হয়নি।"
                    if (ready) tts?.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "shanto_result")
                } else {
                    result.text = "WAITING FOR SCREEN"
                }
            }
        }
        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener { stopSelf() }
        }
        root.addView(result)
        root.addView(scan)
        root.addView(stop)
        bubble = root
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 16; y = 180 }
        windowManager?.addView(root, params)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("bn", "BD")
            ready = true
        }
    }

    override fun onDestroy() {
        bubble?.let { try { windowManager?.removeView(it) } catch (_: Exception) {} }
        virtualDisplay?.release()
        reader?.close()
        projection?.stop()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
